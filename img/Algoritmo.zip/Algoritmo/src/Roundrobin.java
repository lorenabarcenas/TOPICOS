/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author AngelEduardoSanchezG
 */

    import java.util.*;

public class Roundrobin {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Introduce la cantidad de procesos que requeriran de algun recurso: ");
        int n = input.nextInt();

        // Se crea el arreglo de procesos y se llena con datos aleatorios
        int[] burstTime = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.printf("Introduce el tiempo de ejecución del proceso en espera %d: ", i + 1);
            burstTime[i] = input.nextInt();
        }

        System.out.print("Introduce el quantum o unidad de tiempo que ocupara en el procesador un proceso : ");
        int quantum = input.nextInt();

        // Ejecutar el algoritmo de Round Robin
        roundRobin(burstTime, quantum);
    }

    public static void roundRobin(int[] burstTime, int quantum) {
        int n = burstTime.length;
        //un arreglo que guardara el tiempo restante de todos los procesos
        int[] remainingTime = Arrays.copyOf(burstTime, n);
        //un arreglo que guarda el tiempo de espera de un proceso
        int[] waitingTime = new int[n];
        //tiempo de respuesta
        int[] turnaroundTime = new int[n];
        int time = 0;

        while (true) {
            boolean done = true;

            for (int i = 0; i < n; i++) {
                if (remainingTime[i] > 0) {
                    done = false;

                    if (remainingTime[i] > quantum) {
                        time += quantum;
                        remainingTime[i] -= quantum;
                    } else {
                        time += remainingTime[i];
                        waitingTime[i] = time - burstTime[i];
                        remainingTime[i] = 0;
                    }
                }
            }

            if (done) {
                break;
            }
        }

        for (int i = 0; i < n; i++) {
            turnaroundTime[i] = burstTime[i] + waitingTime[i];
        }

        System.out.println("Proceso\tTiempo de ejecución\tTiempo de espera\tTiempo de retorno");
        for (int i = 0; i < n; i++) {
            System.out.printf("%d\t\t%d\t\t\t%d\t\t\t%d\n", i + 1, burstTime[i], waitingTime[i], turnaroundTime[i]);
        }

        double averageWaitingTime = Arrays.stream(waitingTime).average().orElse(Double.NaN);
        double averageTurnaroundTime = Arrays.stream(turnaroundTime).average().orElse(Double.NaN);
        System.out.printf("Tiempo de espera promedio: %.2f\n", averageWaitingTime);
        System.out.printf("Tiempo de retorno promedio: %.2f\n", averageTurnaroundTime);
    }
}


